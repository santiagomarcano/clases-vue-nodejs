// EJERCICIO 1

// function sumaComputacionalmenteCompleja (a, b, cb) {
//   setTimeout(() => {
//     cb(a + b)
//   }, 1000)
// }

// // this

// // llamadas asincronas
// console.log('1')
// sumaComputacionalmenteCompleja(10, 20, resultado => {
//   console.log('1')
// })
// console.log('2')

// FIN EJERCICIO 1

// EJERCICIO 2

// const fs = require('fs')

// // callback hell
// fs.readFile('./prueba.json', (err, data) => {
//   if (err) throw err
// })

// const resultado = fs.readFileSync('./prueba.json')
// console.log('Sincrono', resultado.toString())

// FIN EJERCICIO 2

// EJERCICIO 3

// const list = [1, 2, 3, 4] // x2
// const list2 = [2, 4, 6, 8]
// for (let i = 0; i < list.length; i++) {
//   list2[i] = list[i] * 2
// }

// i === 4

// console.log('hola')
// const listX2 = list.map((elemento) => elemento * 2)
// console.log('hola')

// FIN EJERCICIO 3

// Diferencia let y var
// var message = 'Hello World'

// function suma () {
//   var message1 = '321'
//   let message2 = '123'
//   const message3 = '567'

//   // Si se declara con var/let se puede mutar su valor

//   message2 = '321'

//   // Si se declara con const, no se puede mutar su valor

//   // message3 = '456' // Esto tira error
// }

// Si se declara con var si tengo acceso desde fuera de esa función a message1
// Aqui fuera de suma, no tengo acceso a message2

// Ejercicio 8, el chungo

// Necesitamos un array de ubicaciones de ficheros en nuestro sistema

const ficheros = ['./textos/hello.txt', './textos/hola.txt']

// Lee estos ficheros con una funcion f6

const fs = require('fs')

function f6Sincrono (llista) {
  const resultados = []
  for (let i = 0; i < llista.length; i++) {
    // i = 0 -> './textos/hello.txt' & i = 1 -> './textos/hola.txt'
    const file = fs.readFileSync(llista[i])
    resultados.push(file.toString())
  }
  return resultados
}

const resultados = f6Sincrono(ficheros) // ['hola', 'hello']
console.log('Sincrono', resultados)

function f6Asincrono (llista, callback_final) {
  const resultados = []
  llista.forEach(function (element, index) {
    fs.readFile(element, function (err, data) {
      resultados.push(data.toString())
      if (resultados.length === llista.length) {
        // Forma 1
        // if (index === llista.length - 1) { // Forma 1
        callback_final(resultados)
      }
    })
  })
}

function callback_final (resultados) {
  console.log(resultados)
}

f6Asincrono(ficheros, callback_final)

// .........

// Fin ejercicio 8
